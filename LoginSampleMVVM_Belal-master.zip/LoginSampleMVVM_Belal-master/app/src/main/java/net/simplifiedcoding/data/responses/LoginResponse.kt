package net.simplifiedcoding.data.responses

data class LoginResponse(
    val user: User
)