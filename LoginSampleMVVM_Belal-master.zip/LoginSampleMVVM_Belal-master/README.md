# LoginSampleMVVM_Belal
This pattern uses viewBinding concept
